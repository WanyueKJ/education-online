<?php
//例： '你好，{n}'=>'hello,{n}'
return [
    '您的登陆状态失效，请重新登陆！'=> 'Your logging status is invalid, please login again!',
    '信息错误'=> 'Information error',



];