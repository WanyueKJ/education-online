<?php

return [
        // 默认跳转页面对应的模板文件

   'dispatch_error_tmpl'    => CMF_ROOT . 'themes/simpleboot3/error.html',
   //'exception_tmpl'    => CMF_ROOT . 'themes/simpleboot3/exception.html',

    // +----------------------------------------------------------------------
    // | 异常及错误设置
    // +----------------------------------------------------------------------

    // 异常页面的模板文件
   //'exception_tmpl'         => CMF_ROOT . '/themes/default/404.html',

    // 错误显示信息,非调试模式有效
    //'error_message'          => '页面错误！请稍后再试～',
    // 显示错误信息
    //'show_error_msg'         => false,
    // 异常处理handle类 留空使用 \think\exception\Handle
    //'exception_handle'       => '',
];


