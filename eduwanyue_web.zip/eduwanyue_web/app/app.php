<?php

return [
    // 是否开启多语言
    'lang_switch_on'         => false,
    // 默认语言
    'default_lang'           => 'zh-cn',
	// 默认模块名
    'default_module'         => 'portal',
];


