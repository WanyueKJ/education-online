<?php

namespace app\admin\model;

use think\Model;

/**
 * 课程参与人表
 * @package app\admin\model
 */
class CourseUsersModel extends Model
{

    protected $table = 'cmf_course_users';

}
