<?php

namespace app\admin\model;

use think\Model;

/**
 * 教育表模型
 * @package app\teacher\model
 */
class CourseModel extends Model
{
    protected $table = 'cmf_course';


}
