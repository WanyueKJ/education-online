<?php

namespace app\admin\model;

use think\Model;

/*
 * Ip学级表
 * @package app\admin\model
 */
class IpGardeModel extends Model
{

    protected $table = 'cmf_ip_garde';

}
