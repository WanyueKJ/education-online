<?php

namespace app\admin\model;

use think\Model;

class CourseViewsModel extends Model
{
    protected $table = 'cmf_course_views';

}
