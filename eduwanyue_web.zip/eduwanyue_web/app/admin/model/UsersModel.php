<?php

namespace app\admin\model;

use think\Model;

/*
 * 前台用户表
 * @package app\admin\model
 */
class UsersModel extends Model
{
    protected $table = 'cmf_users';

}
