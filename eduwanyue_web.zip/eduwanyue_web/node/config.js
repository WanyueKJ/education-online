module.exports = {
	'REDISHOST' : '127.0.0.1',
	'REDISPASS' : '',
	'REDISPORT' : '',
	'TOKEN'		: '1234567',
	'sign_key'	: '400d069a791d51ada8af3e6c2979bcd7',
	'socket_port': '19967',
	'WEBADDRESS': 'http:///api/',  //站点域名
	'WEBSITE': 'http://'  //站点域名
}
